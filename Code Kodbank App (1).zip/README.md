
  # Code Kodbank App

  This is a code bundle for Code Kodbank App. The original project is available at https://www.figma.com/design/HhOkmFlbHKX0bd5DCB2k8p/Code-Kodbank-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  