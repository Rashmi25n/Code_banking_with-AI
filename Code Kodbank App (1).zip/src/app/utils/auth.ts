// Simple JWT simulation for demonstration purposes
// WARNING: This is NOT secure and should not be used in production

const SECRET_KEY = 'kodbank_secret_key_demo_2026';

// Base64 encoding/decoding
const base64Encode = (str: string): string => {
  return btoa(str);
};

const base64Decode = (str: string): string => {
  return atob(str);
};

interface JWTPayload {
  sub: string; // subject (username)
  role: string; // role claim
  iat: number; // issued at
  exp: number; // expiry
}

export const generateJWT = (username: string, role: string): string => {
  const header = {
    alg: 'HS256',
    typ: 'JWT'
  };

  const payload: JWTPayload = {
    sub: username,
    role: role,
    iat: Date.now(),
    exp: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
  };

  const encodedHeader = base64Encode(JSON.stringify(header));
  const encodedPayload = base64Encode(JSON.stringify(payload));
  
  // Simple signature simulation (not cryptographically secure)
  const signature = base64Encode(`${encodedHeader}.${encodedPayload}.${SECRET_KEY}`);

  return `${encodedHeader}.${encodedPayload}.${signature}`;
};

export const verifyJWT = (token: string): { valid: boolean; payload?: JWTPayload } => {
  try {
    const parts = token.split('.');
    if (parts.length !== 3) {
      return { valid: false };
    }

    const [encodedHeader, encodedPayload, signature] = parts;
    
    // Verify signature
    const expectedSignature = base64Encode(`${encodedHeader}.${encodedPayload}.${SECRET_KEY}`);
    if (signature !== expectedSignature) {
      return { valid: false };
    }

    // Decode payload
    const payload: JWTPayload = JSON.parse(base64Decode(encodedPayload));

    // Check expiry
    if (payload.exp < Date.now()) {
      return { valid: false };
    }

    return { valid: true, payload };
  } catch (error) {
    return { valid: false };
  }
};

export const getUsernameFromToken = (token: string): string | null => {
  const result = verifyJWT(token);
  return result.valid && result.payload ? result.payload.sub : null;
};

export const getRoleFromToken = (token: string): string | null => {
  const result = verifyJWT(token);
  return result.valid && result.payload ? result.payload.role : null;
};
