// Simulated database using localStorage

export interface KodUser {
  uid: string;
  username: string;
  email: string;
  password: string;
  balance: number;
  phone: string;
  role: 'customer' | 'manager' | 'admin';
}

export interface UserToken {
  tid: string;
  token: string;
  uid: string;
  expiry: number;
}

const USERS_KEY = 'kodbank_users';
const TOKENS_KEY = 'kodbank_tokens';

// User operations
export const getUsers = (): KodUser[] => {
  const data = localStorage.getItem(USERS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveUser = (user: KodUser): void => {
  const users = getUsers();
  users.push(user);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
};

export const getUserByUsername = (username: string): KodUser | null => {
  const users = getUsers();
  return users.find(u => u.username === username) || null;
};

export const userExists = (username: string, email: string): boolean => {
  const users = getUsers();
  return users.some(u => u.username === username || u.email === email);
};

// Token operations
export const getTokens = (): UserToken[] => {
  const data = localStorage.getItem(TOKENS_KEY);
  return data ? JSON.parse(data) : [];
};

export const saveToken = (token: UserToken): void => {
  const tokens = getTokens();
  // Remove any existing tokens for this user
  const filteredTokens = tokens.filter(t => t.uid !== token.uid);
  filteredTokens.push(token);
  localStorage.setItem(TOKENS_KEY, JSON.stringify(filteredTokens));
};

export const getTokenByValue = (tokenValue: string): UserToken | null => {
  const tokens = getTokens();
  return tokens.find(t => t.token === tokenValue) || null;
};

export const deleteToken = (tokenValue: string): void => {
  const tokens = getTokens();
  const filteredTokens = tokens.filter(t => t.token !== tokenValue);
  localStorage.setItem(TOKENS_KEY, JSON.stringify(filteredTokens));
};

// Cookie operations
const AUTH_TOKEN_KEY = 'kodbank_auth_token';

export const setTokenCookie = (token: string): void => {
  localStorage.setItem(AUTH_TOKEN_KEY, token);
};

export const getTokenFromCookie = (): string | null => {
  return localStorage.getItem(AUTH_TOKEN_KEY);
};

export const deleteTokenCookie = (): void => {
  localStorage.removeItem(AUTH_TOKEN_KEY);
};