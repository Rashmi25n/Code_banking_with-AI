import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { getTokenFromCookie, getUserByUsername, deleteTokenCookie } from '../utils/storage';
import { verifyJWT, getUsernameFromToken } from '../utils/auth';
import { toast } from 'sonner';
import { Banknote, LogOut, Wallet, MessageCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { motion, AnimatePresence } from 'motion/react';
import { AIChatModal } from '../components/AIChatModal';

export function Dashboard() {
  const navigate = useNavigate();
  const [username, setUsername] = useState<string>('');
  const [balance, setBalance] = useState<number | null>(null);
  const [showBalance, setShowBalance] = useState(false);
  const [loading, setLoading] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  useEffect(() => {
    // Check if user is authenticated
    const token = getTokenFromCookie();
    
    if (!token) {
      navigate('/login');
      return;
    }

    // Verify JWT token
    const result = verifyJWT(token);
    
    if (!result.valid || !result.payload) {
      deleteTokenCookie();
      navigate('/login');
      return;
    }

    // Extract username from token
    const usernameFromToken = getUsernameFromToken(token);
    if (usernameFromToken) {
      setUsername(usernameFromToken);
    }
  }, [navigate]);

  const handleCheckBalance = () => {
    setLoading(true);

    // Get token from cookie
    const token = getTokenFromCookie();

    if (!token) {
      toast.error('No authentication token found');
      navigate('/login');
      return;
    }

    // Verify token
    const result = verifyJWT(token);

    if (!result.valid || !result.payload) {
      toast.error('Invalid or expired token. Please login again.');
      deleteTokenCookie();
      navigate('/login');
      return;
    }

    // Extract username from token
    const usernameFromToken = getUsernameFromToken(token);

    if (!usernameFromToken) {
      toast.error('Unable to extract user information from token');
      setLoading(false);
      return;
    }

    // Fetch user balance from "database"
    const user = getUserByUsername(usernameFromToken);

    if (!user) {
      toast.error('User not found');
      setLoading(false);
      return;
    }

    // Set balance and show with animation
    setTimeout(() => {
      setBalance(user.balance);
      setShowBalance(true);
      setLoading(false);

      // Trigger party popper animation
      triggerConfetti();
    }, 500);
  };

  const triggerConfetti = () => {
    const duration = 3000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval: ReturnType<typeof setInterval> = setInterval(function() {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);

      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
      });
    }, 250);
  };

  const handleLogout = () => {
    deleteTokenCookie();
    toast.success('Logged out successfully');
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-violet-600 via-purple-600 to-indigo-700 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 pt-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 backdrop-blur-sm rounded-full">
              <Banknote className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl text-white">Code Kodbank</h1>
              <p className="text-sm text-white/80">Welcome, {username}</p>
            </div>
          </div>
          <Button
            onClick={handleLogout}
            variant="outline"
            className="gap-2 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </div>

        {/* Dashboard Content */}
        <div className="grid gap-6">
          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Account Dashboard
              </CardTitle>
              <CardDescription>View your account balance</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <Button
                onClick={handleCheckBalance}
                disabled={loading}
                className="w-full bg-indigo-600 hover:bg-indigo-700 h-12 text-lg"
              >
                {loading ? 'Loading...' : 'Check Balance'}
              </Button>

              <Button
                onClick={() => setIsChatOpen(true)}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 h-12 text-lg gap-2"
              >
                <MessageCircle className="w-5 h-5" />
                Ask guys
              </Button>

              {/* Balance Display with Animation */}
              <AnimatePresence>
                {showBalance && balance !== null && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.8, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.8, y: 20 }}
                    transition={{ duration: 0.5, type: "spring" }}
                    className="relative"
                  >
                    <div className="p-8 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-lg text-center relative overflow-hidden">
                      {/* Animated background circles */}
                      <motion.div
                        className="absolute top-0 left-0 w-32 h-32 bg-white/10 rounded-full blur-xl"
                        animate={{
                          scale: [1, 1.2, 1],
                          x: [0, 50, 0],
                          y: [0, 30, 0],
                        }}
                        transition={{
                          duration: 4,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                      <motion.div
                        className="absolute bottom-0 right-0 w-40 h-40 bg-white/10 rounded-full blur-xl"
                        animate={{
                          scale: [1, 1.3, 1],
                          x: [0, -30, 0],
                          y: [0, -50, 0],
                        }}
                        transition={{
                          duration: 5,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />

                      {/* Content */}
                      <div className="relative z-10">
                        <motion.p
                          className="text-white text-3xl"
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.3, type: "spring" }}
                        >
                          Your balance is: ₹{balance.toLocaleString()}
                        </motion.p>
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 0.6 }}
                          className="text-white/90 text-lg mt-4"
                        >
                          🎉 🎊 🎈
                        </motion.div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* AI Chat Modal */}
      <AIChatModal isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />
    </div>
  );
}