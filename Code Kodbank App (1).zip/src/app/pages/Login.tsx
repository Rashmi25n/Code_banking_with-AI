import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card';
import { getUserByUsername, saveToken, setTokenCookie } from '../utils/storage';
import { generateJWT } from '../utils/auth';
import { toast } from 'sonner';
import { Banknote } from 'lucide-react';

export function Login() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Validation
    if (!formData.username || !formData.password) {
      toast.error('Username and password are required');
      setLoading(false);
      return;
    }

    // Get user from "database"
    const user = getUserByUsername(formData.username);

    // Validate credentials
    if (!user || user.password !== formData.password) {
      toast.error('Invalid username or password');
      setLoading(false);
      return;
    }

    // Generate JWT token with username as subject and role as claim
    const token = generateJWT(user.username, user.role);

    // Store token in "database"
    const tokenRecord = {
      tid: `tid_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      token: token,
      uid: user.uid,
      expiry: Date.now() + 24 * 60 * 60 * 1000 // 24 hours
    };
    saveToken(tokenRecord);

    // Set token as cookie
    setTokenCookie(token);

    toast.success('Login successful!');
    setLoading(false);

    // Navigate to dashboard
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="space-y-1 text-center">
          <div className="flex justify-center mb-4">
            <div className="p-3 bg-indigo-600 rounded-full">
              <Banknote className="w-8 h-8 text-white" />
            </div>
          </div>
          <CardTitle className="text-3xl">Code Kodbank</CardTitle>
          <CardDescription>Login to your account</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                name="username"
                type="text"
                placeholder="Enter username"
                value={formData.username}
                onChange={handleChange}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="Enter password"
                value={formData.password}
                onChange={handleChange}
                required
              />
            </div>

            <Button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700" disabled={loading}>
              {loading ? 'Logging in...' : 'Login'}
            </Button>

            <div className="text-center text-sm">
              Don't have an account?{' '}
              <button
                type="button"
                onClick={() => navigate('/register')}
                className="text-indigo-600 hover:underline"
              >
                Register here
              </button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}